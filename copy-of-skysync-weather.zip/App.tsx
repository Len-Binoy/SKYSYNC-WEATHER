
import React, { useState, useEffect, useCallback } from 'react';
import { fetchWeather } from './services/geminiService';
import { WeatherData } from './types';
import WeatherCard from './components/WeatherCard';
import ForecastChart from './components/ForecastChart';

const DEFAULT_CITIES = ['Delhi', 'New York', 'London', 'Beijing'];

const App: React.FC = () => {
  const [featuredWeather, setFeaturedWeather] = useState<Record<string, WeatherData | null>>({});
  const [searchResults, setSearchResults] = useState<WeatherData | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [loadingDefaults, setLoadingDefaults] = useState<Record<string, boolean>>({});
  const [error, setError] = useState<string | null>(null);

  const loadDefaultWeather = useCallback(async () => {
    DEFAULT_CITIES.forEach(async (city) => {
      setLoadingDefaults(prev => ({ ...prev, [city]: true }));
      try {
        const data = await fetchWeather(city);
        setFeaturedWeather(prev => ({ ...prev, [city]: data }));
      } catch (err) {
        console.error(`Failed to fetch weather for ${city}`, err);
      } finally {
        setLoadingDefaults(prev => ({ ...prev, [city]: false }));
      }
    });
  }, []);

  useEffect(() => {
    loadDefaultWeather();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setError(null);
    try {
      const data = await fetchWeather(searchQuery);
      setSearchResults(data);
    } catch (err) {
      setError("Failed to find location. Please try again.");
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 md:p-8 lg:p-12 selection:bg-blue-500 selection:text-white">
      {/* Header & Search */}
      <header className="max-w-6xl mx-auto mb-12 flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight text-white mb-2 italic">
            SKY<span className="text-blue-500">SYNC</span>
          </h1>
          <p className="text-slate-400 font-medium">Precision Weather via Gemini Intelligence</p>
        </div>

        <form onSubmit={handleSearch} className="w-full md:w-96 relative group">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search any city..."
            className="w-full bg-slate-900 border border-slate-700 rounded-full py-4 px-6 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all text-lg font-medium shadow-inner"
          />
          <button 
            type="submit"
            disabled={isSearching}
            className="absolute right-2 top-2 bottom-2 px-6 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 rounded-full text-sm font-bold uppercase tracking-widest transition-colors shadow-lg"
          >
            {isSearching ? '...' : 'Find'}
          </button>
        </form>
      </header>

      <main className="max-w-6xl mx-auto space-y-12">
        {/* Search Results / Main Spotlight */}
        {searchResults && (
          <section className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-blue-400 mb-6 flex items-center gap-2">
              <span className="h-px w-8 bg-blue-400/50"></span>
              Search Result
            </h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <WeatherCard data={searchResults} isLoading={isSearching} featured />
              </div>
              <div className="lg:col-span-2 bg-slate-900/50 rounded-3xl p-8 border border-white/5 backdrop-blur-sm flex flex-col justify-between">
                <div>
                  <h3 className="text-2xl font-bold mb-4">Daily Insights</h3>
                  <p className="text-slate-300 leading-relaxed text-lg italic">
                    {searchResults.description}
                  </p>
                </div>
                
                <ForecastChart data={searchResults.forecast} />

                {searchResults.sources.length > 0 && (
                  <div className="mt-8">
                    <h4 className="text-[10px] uppercase text-slate-500 font-bold tracking-widest mb-2">Sources Found</h4>
                    <div className="flex flex-wrap gap-2">
                      {searchResults.sources.map((source, idx) => (
                        <a 
                          key={idx} 
                          href={source.uri} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[10px] bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-full text-slate-400 transition-colors border border-white/5"
                        >
                          {source.title.substring(0, 20)}...
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </section>
        )}

        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-2xl text-center">
            {error}
          </div>
        )}

        {/* Default Cities Section */}
        <section>
          <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-slate-500 mb-8 flex items-center gap-2">
            <span className="h-px w-8 bg-slate-700"></span>
            Global Pulse
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {DEFAULT_CITIES.map((city) => (
              <WeatherCard 
                key={city}
                data={featuredWeather[city] || null}
                isLoading={loadingDefaults[city]}
                onClick={() => {
                   setSearchQuery(city);
                   // Trigger search immediately
                   fetchWeather(city).then(setSearchResults);
                }}
              />
            ))}
          </div>
        </section>
      </main>

      <footer className="max-w-6xl mx-auto mt-24 border-t border-slate-900 pt-8 pb-12 flex flex-col md:flex-row justify-between items-center opacity-50 text-xs gap-4">
        <p>© 2025 SkySync Weather. Powered by Google Gemini.</p>
        <div className="flex gap-6">
          <span className="hover:text-blue-400 cursor-help transition-colors">Privacy</span>
          <span className="hover:text-blue-400 cursor-help transition-colors">API Docs</span>
          <span className="hover:text-blue-400 cursor-help transition-colors">Terms of Service</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
