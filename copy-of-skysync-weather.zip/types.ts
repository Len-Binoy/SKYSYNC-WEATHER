
export interface WeatherData {
  city: string;
  temperature: string;
  condition: string;
  humidity: string;
  windSpeed: string;
  description: string;
  forecast: Array<{ day: string; temp: number }>;
  sources: Array<{ title: string; uri: string }>;
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export enum WeatherCategory {
  SUNNY = 'Sunny',
  CLOUDY = 'Cloudy',
  RAINY = 'Rainy',
  SNOWY = 'Snowy',
  STORM = 'Storm',
  UNKNOWN = 'Unknown'
}
