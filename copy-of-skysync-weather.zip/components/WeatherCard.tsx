
import React from 'react';
import { WeatherData } from '../types';

interface WeatherCardProps {
  data: WeatherData | null;
  isLoading: boolean;
  onClick?: () => void;
  featured?: boolean;
}

const WeatherCard: React.FC<WeatherCardProps> = ({ data, isLoading, onClick, featured }) => {
  if (isLoading) {
    return (
      <div className={`animate-pulse bg-slate-800/50 border border-slate-700 rounded-3xl p-6 h-full flex flex-col justify-between ${featured ? 'min-h-[300px]' : ''}`}>
        <div className="h-6 w-1/2 bg-slate-700 rounded mb-4"></div>
        <div className="h-16 w-3/4 bg-slate-700 rounded mb-4"></div>
        <div className="h-4 w-full bg-slate-700 rounded"></div>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div 
      onClick={onClick}
      className={`group cursor-pointer transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]
        bg-gradient-to-br from-slate-800/80 to-slate-900/80 backdrop-blur-xl border border-white/10 
        rounded-3xl p-6 shadow-2xl flex flex-col justify-between
        ${featured ? 'md:col-span-2 lg:col-span-1 border-blue-500/30 ring-1 ring-blue-500/20' : ''}`}
    >
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-xl font-bold text-white/90 group-hover:text-blue-400 transition-colors uppercase tracking-wider">{data.city}</h3>
          <p className="text-slate-400 text-sm font-medium">{data.condition}</p>
        </div>
        <div className="text-4xl">
           {data.condition.toLowerCase().includes('sun') ? '☀️' : 
            data.condition.toLowerCase().includes('rain') ? '🌧️' : 
            data.condition.toLowerCase().includes('cloud') ? '☁️' : '🌤️'}
        </div>
      </div>

      <div className="my-4">
        <span className="text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400 tracking-tighter">
          {data.temperature}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4 border-t border-white/5 pt-4">
        <div className="flex flex-col">
          <span className="text-[10px] uppercase text-slate-500 font-bold tracking-widest">Humidity</span>
          <span className="text-slate-200 font-semibold">{data.humidity}</span>
        </div>
        <div className="flex flex-col">
          <span className="text-[10px] uppercase text-slate-500 font-bold tracking-widest">Wind</span>
          <span className="text-slate-200 font-semibold">{data.windSpeed}</span>
        </div>
      </div>
      
      {featured && (
         <div className="mt-4 text-xs italic text-slate-500 line-clamp-2">
            "{data.description}"
         </div>
      )}
    </div>
  );
};

export default WeatherCard;
